/*
 * Aria Templates
 * Copyright Amadeus s.a.s.
 */
/**
 * Template script definition for aria.tester.runner.view.Report
 */
Aria.tplScriptDefinition({
    $classpath : 'aria.tester.runner.view.popup.PopupScript',
    $dependencies : ['aria.tester.runner.utils.TestUtils'],
    $prototype : {



    }
});
