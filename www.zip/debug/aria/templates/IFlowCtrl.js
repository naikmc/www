/*
 * Aria Templates
 * Copyright Amadeus s.a.s.
 */
/**
 * Flow controller base interface (currently empty, but may be completed later).
 * @class aria.templates.IFlowCtrl
 */
Aria.interfaceDefinition({
    $classpath : 'aria.templates.IFlowCtrl',
    $interface : {}
});
