/*
 * Aria Templates
 * Copyright Amadeus s.a.s.
 */
/**
 * Wrapper around a Section Object and it's DOM Element
 * @class aria.templates.SectionWrapper
 * @extends aria.core.JsObject
 */
Aria.classDefinition({
    $classpath : 'aria.templates.SectionWrapper',
    $extends : 'aria.templates.DomElementWrapper',
    $dependencies : ['aria.utils.DomOverlay', 'aria.utils.Dom'],
    /**
     * Create a Wrapper object to allow safe changes in the DOM without giving direct access to the DOM. Note that a
     * closure is used to prevent access to the domElt object from the template.
     * @param {HTMLElement} domElt DOM element which is wrapped
     * @param {aria.templates.Section} sectionObject Section object which is wrapped
     */
    $constructor : function (domElt, sectionObject) {
        if (domElt) {
            while (domElt.nodeType != 1) {
                domElt = domElt.parentNode;
            }
        }
        this.$DomElementWrapper.constructor.call(this, domElt, sectionObject.tplCtxt);

        /**
         * Dynamically insert an adjacent section, without refreshing any other section.
         * @param {String} where May be one of: beforeBegin, afterBegin, beforeEnd, afterEnd
         * @param {String|aria.templates.CfgBeans:SectionCfg} sectionParam A string containing the new section id, or an
         * object containing the new section configuration.
         */
        this.insertAdjacentSection = function (where, sectionParam) {
            if (where != "beforeBegin" && where != "afterBegin" && where != "beforeEnd" && where != "afterEnd") {
                this.$logError(aria.utils.Dom.INSERT_ADJACENT_INVALID_POSITION, [where]);
                return;
            }
            sectionObject.tplCtxt.insertAdjacentSections({
                position : where,
                refSection : {
                    domElt : domElt,
                    object : sectionObject
                },
                sections : [sectionParam]
            });
        };

        /**
         * Remove the section dynamically from the DOM.
         */
        this.remove = function () {
            sectionObject.$dispose();
            var parentNode = domElt.parentNode;
            aria.utils.Dom.removeElement(domElt);
            aria.utils.Dom.refreshDomElt(parentNode);
            this.$dispose();
        };

        /**
         * Set the state of the processing indicator. It updates the datamodel if the section has a processing binding
         * @param {Boolean} visible True if the loading indicator should be visible
         * @param {String} message Text message to display inside the loading indicator
         */
        this.setProcessingIndicator = function (visible, message) {
            var overlay, doRegistration = true;

            if (visible) {
                overlay = aria.utils.DomOverlay.create(domElt, message);
            } else {
                overlay = aria.utils.DomOverlay.detachFrom(domElt);

                if (!overlay) {
                    // Trying to remove an overlay from an element that has no overlay attached
                    doRegistration = false;
                }
            }

            // Update the binding in the datamodel
            if (doRegistration) {
                sectionObject.registerProcessingIndicator(visible, overlay);
            }
        };

        var parentClassListSetClassName = this.classList.setClassName;
        this.classList.setClassName = function (className) {
            parentClassListSetClassName.call(this, className);
            sectionObject.updateClassList(className);
        };

        var parentDispose = this._dispose;
        /**
         * Clean the variables inside the closure.
         * @private
         */
        this._dispose = function () {
            parentDispose.call(this);
            sectionObject = null;
            parentDispose = null;
        };
    },
    $prototype : {}
});
