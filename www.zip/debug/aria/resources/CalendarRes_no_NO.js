/*
 * Aria Templates
 * Copyright Amadeus s.a.s.
 */
/**
 * Aria resource object for calendar no_NO
 */
Aria.resourcesDefinition({
    $classpath : 'aria.resources.CalendarRes',
    $resources : {
        today : "I dag",
        selectedDate : "Valgt dato"
    }
});
