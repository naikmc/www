/*
 * Aria Templates
 * Copyright Amadeus s.a.s.
 */
/**
 * Aria resource object for calendar kl_GL
 */
Aria.resourcesDefinition({
    $classpath : 'aria.resources.CalendarRes',
    $resources : {
        today : "Ullumi",
        selectedDate : "Ullut qinikkat"
    }
});
