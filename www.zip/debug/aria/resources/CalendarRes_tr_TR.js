/*
 * Aria Templates
 * Copyright Amadeus s.a.s.
 */
/**
 * Aria resource object for calendar tr_TR
 */
Aria.resourcesDefinition({
    $classpath : 'aria.resources.CalendarRes',
    $resources : {
        today : "Bug\u00fcn",
        selectedDate : "Se\u00e7ilen tarih"
    }
});
