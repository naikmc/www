/*
 * Aria Templates
 * Copyright Amadeus s.a.s.
 */
/**
 * Aria resource object for calendar fr_FR
 */
Aria.resourcesDefinition({
    $classpath : 'aria.resources.CalendarRes',
    $resources : {
        today : "Aujourd'hui",
        selectedDate : "Date s\u00e9lectionn\u00e9e"
    }
});
