/*
 * Aria Templates
 * Copyright Amadeus s.a.s.
 */
/**
 * Aria resource object for multiselect footer ar_SA (Arabic)
 */
Aria.resourcesDefinition({
    $classpath : 'aria.resources.multiselect.FooterRes',
    $resources : {
        selectAll : "\u062a\u062d\u062f\u064a\u062f\u0020\u0627\u0644\u0643\u0644",
        deselectAll : "\u0623\u0644\u063a\u064a\u0020\u0623\u062e\u062a\u064a\u0627\u0631\u0020\u0627\u0644\u0643\u0644",
        close : "\u0623\u063a\u0644\u0627\u0642"
    }
});
