/*
 * Aria Templates
 * Copyright Amadeus s.a.s.
 */
/**
 * Aria resource object for calendar fi_FI
 */
Aria.resourcesDefinition({
    $classpath : 'aria.resources.CalendarRes',
    $resources : {
        today : "T\u00e4n\u00e4\u00e4n",
        selectedDate : "Valittu p\u00e4iv\u00e4"
    }
});
