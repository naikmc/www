/*
 * Aria Templates
 * Copyright Amadeus s.a.s.
 */
/**
 * Aria resource object for calendar is_IS
 */
Aria.resourcesDefinition({
    $classpath : 'aria.resources.CalendarRes',
    $resources : {
        today : "\u00cd dag",
        selectedDate : "Valinn dagur"
    }
});
