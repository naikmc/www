/*
 * Aria Templates
 * Copyright Amadeus s.a.s.
 */
/**
 * Aria resource object for calendar ru_RU
 */
Aria.resourcesDefinition({
    $classpath : 'aria.resources.CalendarRes',
    $resources : {
        today : "\u0421\u0435\u0433\u043e\u0434\u043d\u044f",
        selectedDate : "\u0412\u044b\u0431\u0440\u0430\u043d\u043d\u0430\u044f \u0434\u0430\u0442\u0430"
    }
});
