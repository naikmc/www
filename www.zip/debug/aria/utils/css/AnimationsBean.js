/*
 * Aria Templates
 * Copyright Amadeus s.a.s.
 */
Aria.beanDefinitions({
    $package : "aria.utils.css.AnimationsBean",
    $description : "Definition of parameters used by Animations class",
    $namespaces : {
        "json" : "aria.core.JsonTypes"
    },
    $beans : {
        "AnimationCfg" : {
            $type : "json:Object",
            $description : "Parameters for aria.utils.css.Animations",
            $properties : {
                "from" : {
                    $type : "json:ObjectRef",
                    $description : "HTMLElement to animate out"
                },
                "to" : {
                    $type : "json:ObjectRef",
                    $description : "HTMLElement to animate in"
                },
                "reverse" : {
                    $type : "json:Boolean",
                    $description : "property that activates the reverse of the animation called"
                },
                "type" : {
                    $type : "json:Integer",
                    $description : "type of animation to activate (1: normal/2: with hardware acceleration/3: 3D)"
                },
                "hiddenClass" : {
                    $type : "json:String",
                    $description : "className to apply to the element animate out and to remove from the element animate in"
                }
            }
        },
        "AnimationName" : {
            $type : "json:MultiTypes",
            $description : "The name of the animation",
            $sample : "slide left",
            $contentTypes : [{
                $type : "json:Enum",
                $description : "Predefined framework animation",
                $enumValues : ["slide left", "slide right", "slide up", "slide down", "fade", "fade reverse",
                    "pop", "pop reverse", "flip", "flip reverse"]
            }, {
                $type : "json:String",
                $description : "Custom animation"
            }]
        }
    }
});
