/*
 * Aria Templates
 * Copyright Amadeus s.a.s.
 */
Aria.resourcesDefinition({
    $classpath : 'aria.utils.UtilsRes',
    $resources : {
        "timeFormatLabels" : {
            "am" : "AM",
            "pm" : "PM"
        }
    }
});
