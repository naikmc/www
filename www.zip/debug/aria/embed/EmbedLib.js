/*
 * Aria Templates
 * Copyright Amadeus s.a.s.
 */
Aria.classDefinition({
    $classpath : "aria.embed.EmbedLib",
    $extends : "aria.widgetLibs.WidgetLib",
    $singleton : true,
    $prototype : {
        widgets : {
            "Element" : "aria.embed.Element",
            "Map" : "aria.embed.Map",
            "Placeholder" : "aria.embed.Placeholder"
        }
    }
});
